class Config:
    SECRET_KEY = 'your_secret_key_here'
